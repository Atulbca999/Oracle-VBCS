define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class loadProductStockChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application } = context;

      const callRestResult = await Actions.callRest(context, {
        endpoint: 'businessObjects/get_ProductStock',
        responseType: 'getProductStockResponse',
        uriParams: {
          'ProductStock_Id': $page.variables.productStockId,
        },
      }, { id: 'loadProductStock' });

      if (!callRestResult.ok) {
        // Create error message
        const errorMessage = callRestResult.body?.detail || callRestResult.body?.['o:errorDetails']?.[0]?.detail || `Could not load data: status ${callRestResult.status}`;
        // Fires a notification event about failed load
        await Actions.fireNotificationEvent(context, {
          summary: 'Could not load data',
          message: errorMessage,
        }, { id: 'fireErrorNotification' });

        return;
      }

      $page.variables.fetchedProductStock = callRestResult.body;
      $page.variables.productStock = $page.variables.fetchedProductStock;
      $page.variables.productStockETag = callRestResult.headers.get('ETag');
    }
  }

  return loadProductStockChain;
});
