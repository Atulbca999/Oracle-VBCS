define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ButtonActionChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application } = context;

      const forEachResult = await ActionUtils.forEach($page.variables.prodDtlADP.data, async (item, index) => {

        const callRestBusinessObjectsUpdateProductDetailsResult = await Actions.callRest(context, {
          endpoint: 'businessObjects/update_ProductDetails',
          uriParams: {
            'ProductDetails_Id': $page.variables.prodDtlADP.data[index].ProductCode,
          },
          body: $page.variables.prodDtlADP.data[index],
        });
      }, { mode: 'serial' });

      await Actions.fireNotificationEvent(context, {
        type: 'confirmation',
        summary: 'Product updated succesfully.',
        displayMode: 'transient',
      });
    }
  }

  return ButtonActionChain;
});
