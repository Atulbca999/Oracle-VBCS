define([], () => {
  'use strict';

  class PageModule {
    processFile(fileSet) {
        
    let reader = new FileReader();
    return new Promise(function(resolve, reject) {
        let reader = new FileReader();
    
        reader.onloadend = function(e) {
           let data = e.target.result;
           let workbook = XLSX.read(data, {type: 'binary'});
           let first_worksheet = workbook.Sheets[workbook.SheetNames[0]];
           let jsonArr = XLSX.utils.sheet_to_json(first_worksheet, {header:1});          
           resolve(jsonArr);
        };
        reader.readAsBinaryString(fileSet); 
     });
  };

  populateData (jsonArr) {
     let parts = [];
     let final = {};
      let headerArray= ['productCategory','productDesc','productPrice','productWeight'];    
    
        for (let j = 1; j < jsonArr.length; j++){
          let obj = {};
          let partObject ={};
          for (let i = 0; i < jsonArr[0].length; i++) {
            let objName = headerArray[i];
            let objValue = jsonArr[j][i];    
            obj[objName] = objValue;
          }
         
          partObject["id"]="part"+j;
          partObject["path"]="/ProductDetails"; // This is the Business Object name
          partObject["operation"]="create"; // Operation to perform on business object
          partObject["payload"]=obj;

          parts.push(partObject);
      }
      final["parts"] = parts;
     
  
     
     return final;
  };

  downloadProductSample(){
    let dwnldFile = require.toUrl('resources/file/Product.xlsx');
    return dwnldFile;
  }

  

  }
  
  return PageModule;
});
