define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class navigateToEditProductStockChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.productStockId
     */
    async run(context, { productStockId }) {
      const { $page, $flow, $application } = context;
      const navigateToPageMainEditProductStockResult = await Actions.navigateToPage(context, {
        page: 'main-edit-product-stock',
        params: {
          productStockId: productStockId,
        },
      });
    }
  }

  return navigateToEditProductStockChain;
});
