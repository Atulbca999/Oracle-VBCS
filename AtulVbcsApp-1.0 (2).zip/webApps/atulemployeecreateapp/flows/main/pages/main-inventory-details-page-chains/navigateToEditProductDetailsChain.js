define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class navigateToEditProductDetailsChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.productDetailsId
     */
    async run(context, { productDetailsId }) {
      const { $page, $flow, $application } = context;
      const navigateToPageMainEditProductDetailsResult = await Actions.navigateToPage(context, {
        page: 'main-edit-product-details',
        params: {
          productDetailsId: productDetailsId,
        },
      });
    }
  }

  return navigateToEditProductDetailsChain;
});
