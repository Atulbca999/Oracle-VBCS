define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ojTable8696568902ChangeSelectionChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.productStockId
     */
    async run(context, { productStockId }) {
      const { $page, $flow, $application } = context;
      $page.variables.oj_table_869656890_2SelectedId = productStockId;
    }
  }

  return ojTable8696568902ChangeSelectionChain;
});
