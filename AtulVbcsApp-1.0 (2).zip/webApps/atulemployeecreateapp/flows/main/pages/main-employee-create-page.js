define([], () => {
  'use strict';

  class PageModule {
    addFun (){
    let currentDate = new Date();
    let futureDate = new Date();
    // Increase the number of days -- 10 days in this example
    futureDate.setDate( currentDate.getDate() + 10 );
    return futureDate;
  }

    minusFun (){
    let currentDate = new Date();
    let pastDate = new Date();
    // Decrease the number of days -- 10 days in this example
    pastDate.setDate( currentDate.getDate() - 10 );
    return pastDate;
  }
  }
  
  return PageModule;
});
