define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class UploadButtonActionChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application } = context;

      const fileData = await $page.functions.processFile($page.variables.FileReference);

      const callFunctionResult = await $page.functions.populateData(fileData);

      const callRestBusinessObjectsBatchResult = await Actions.callRest(context, {
        endpoint: 'businessObjects/batch',
        body: callFunctionResult,
      });

      if (callRestBusinessObjectsBatchResult.ok) {
        await Actions.fireNotificationEvent(context, {
          summary: 'File uploaded Sucessfully.',
          type: 'confirmation',
        });
      } else {
        await Actions.fireNotificationEvent(context, {
          summary: 'Issue occured while uploading the file.',
        });
      }

      await Actions.resetVariables(context, {
        variables: [
          '$page.variables.disableFileUploadBtn',
        ],
      });

      await Actions.fireDataProviderEvent(context, {
        target: $page.variables.productDetailsListSDP,
        refresh: null,
      });
    }
  }

  return UploadButtonActionChain;
});
