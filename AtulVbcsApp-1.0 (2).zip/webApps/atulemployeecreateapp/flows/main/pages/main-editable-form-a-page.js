define([], () => {
  'use strict';

  class PageModule {


processFile (fileSet) {
    let reader = new FileReader();
    return new Promise(function (resolve, reject) {
      let reader = new FileReader();
      reader.onloadend = function (e) {
        let data = e.target.result;
        let workbook = XLSX.read(data, { type: 'binary' });
        let first_worksheet = workbook.Sheets[workbook.SheetNames[0]];
        let jsonArr = XLSX.utils.sheet_to_json(first_worksheet, { header: 1 });
        resolve(jsonArr);
      };
      reader.readAsBinaryString(fileSet);
    });
  };

   populateData (jsonArr) {
    let emp = [];
    let final = [];
    let headerArrays = ['department','email','firstName','hireDate','lastName','phoneNumber','salary'];
    for (let i = 1; i < jsonArr.length; i++) {
      let obj = {};
      let empObj = {};
      for (let k = 0; k < jsonArr[0].length; k++) {
        let objNm = headerArrays[i];
        let objVal = jsonArr[i][k] ;
        obj[objNm] = objVal;
      }

      empObj["id"] = "emp"+i;
      empObj["path"] = "/Employee";
      empObj["operation"] = "create";
      empObj["payload"] = obj;
      
      emp.push(empObj);

    }
    final["emp"] = emp;

    return final;
  };

  }

  
  return PageModule;
});
