define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ojTable8696568901ChangeSelectionChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.productDetailsId
     */
    async run(context, { productDetailsId }) {
      const { $page, $flow, $application } = context;
      $page.variables.oj_table_869656890_1SelectedId = productDetailsId;
    }
  }

  return ojTable8696568901ChangeSelectionChain;
});
