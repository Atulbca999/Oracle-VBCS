define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ButtonActionChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application } = context;

      const callFunctionResult = await $page.functions.processFile($page.variables.File);

      const callFunction2Result = await $page.functions.populateData(callFunctionResult);

      const callRestBusinessObjectsBatchResult = await Actions.callRest(context, {
        endpoint: 'businessObjects/batch',
      });

      await Actions.fireNotificationEvent(context, {
        summary: 'File processed Sucessfully.',
        type: 'info',
      });
    }
  }

  return ButtonActionChain;
});
