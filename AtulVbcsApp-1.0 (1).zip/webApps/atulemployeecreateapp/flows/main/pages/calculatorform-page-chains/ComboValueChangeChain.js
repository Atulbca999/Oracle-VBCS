define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ComboValueChangeChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.value 
     */
    async run(context, { value }) {
      const { $page, $flow, $application } = context;

      switch (value) {
        case '+':
          $page.variables.result = $page.variables.num1+$page.variables.num2;
          break;
        case '-':
          $page.variables.result = $page.variables.num1-$page.variables.num2;
          break;
        case '*':
          $page.variables.result = $page.variables.num1*$page.variables.num2;
          break;
        case '/':
          $page.variables.result = $page.variables.num1/$page.variables.num2;
          break;
        case '%':
          $page.variables.result = $page.variables.num1%$page.variables.num2;
          break;
        default:
          break;
      }
    }
  }

  return ComboValueChangeChain;
});
