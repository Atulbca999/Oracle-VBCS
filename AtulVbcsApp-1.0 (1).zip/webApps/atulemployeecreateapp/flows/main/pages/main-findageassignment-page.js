define([], () => {
  'use strict';

  class PageModule {
    
    findAge(dob){
      if(dob === null){
        return null;
      }else{
        
      return ((new Date() - new Date(dob)) / (60*60*24*1000*365)).toFixed(0);
      }

    }
    
  }
  
  return PageModule;
});
